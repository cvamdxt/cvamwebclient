<!-- DO NOT POST LINKS OR REFERENCES TO COPYRIGHTED CONTENT IN YOUR ISSUE. -->

<!-- Issue with the desktop app? Post here: https://github.com/webtorrent/webtorrent-desktop/issues -->

**What version of WebTorrent?**

**What operating system and Node.js version?**

**What browser and version? (if using WebTorrent in the browser)**

**What did you expect to happen?**

**What actually happened?**
